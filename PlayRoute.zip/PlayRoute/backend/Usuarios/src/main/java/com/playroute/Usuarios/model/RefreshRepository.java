package com.playroute.Usuarios.model;

import java.time.Instant;
import jakarta.persistence.*;
@Entity
@Table(name = "sesiones_refresh")
public class RefreshRepository {
@Id
    public String refreshToken;

    public Long usuarioId;
    public Instant expiratesIn;

    public RefreshSession() {
    }

    public RefreshSession(String hash, Long user, Instant expiry) {
        this.refreshToken = hash;
        this.usuarioId = user;
        this.expiratesIn = expiry;
    }
}
