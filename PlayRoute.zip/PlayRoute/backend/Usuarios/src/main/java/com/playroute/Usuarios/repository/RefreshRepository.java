package com.playroute.Usuarios.repository;

import java.util.Optional;
import com.playroute.Usuarios.model.*;
public interface RefreshRepository extends JpaRepository<RefreshSession, String>{
 @Lock(LockModeType.PESSIMISTIC_WRITE)
  @Query("select s from RefreshSession s where s.tokenHash=:hash")
  Optional<RefreshSession> bloquear(String hash);

  void deleteByUsuarioId(Long usuarioId);
}