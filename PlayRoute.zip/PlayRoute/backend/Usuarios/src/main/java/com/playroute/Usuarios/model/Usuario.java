package com.playroute.Usuarios.model;

@Entity 
@Table (name = "usuario")
public class Usuario {

    @Id 
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @Column (unique = true, nullable = false)
    private String nombre;

    @Column (unique = true, nullable = false)
    private String correo;

    @Column (nullable = false)
    private String contraseña;
    @Column (nullable = false)
    private String rol = "MIEMBRO";

    public boolean activo = true;
    public Usuario(){}
}
