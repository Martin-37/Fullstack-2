package com.playroute.Usuarios.DTO;
public record Session(String tokenAcess, long expiratesIn, UsuarioResponse usuario) {}

