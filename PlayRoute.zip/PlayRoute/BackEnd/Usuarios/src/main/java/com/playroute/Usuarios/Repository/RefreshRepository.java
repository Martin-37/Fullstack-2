package main.java.com.playroute.Usuarios.Repository;
import java.util.Optional;
import jakarta.persistence.LockModeType;
import main.java.com.playroute.Usuarios.Model.RefreshSession;

public interface RefreshRepository extends JpaRepository<RefreshSession, String>{
 @Lock(LockModeType.PESSIMISTIC_WRITE)
  @Query("select s from RefreshSession s where s.tokenHash=:hash")
  Optional<RefreshSession> bloquear(String hash);

  void deleteByUsuarioId(Long usuarioId);
}
