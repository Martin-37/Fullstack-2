package com.playroute.Usuarios.Model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity 
@Table (name = "usuario")
public class Usuario {

    @Id 
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column (unique = true, nullable = false)
    private String nombre;

    @Column (unique = true, nullable = false)
    private String correo;

    @Column (nullable = false)
    private String contraseña;
    @Column (nullable = false)
    private String rol = "MIEMBRO";

    public boolean activo = true;
    public Usuario(){}
}
