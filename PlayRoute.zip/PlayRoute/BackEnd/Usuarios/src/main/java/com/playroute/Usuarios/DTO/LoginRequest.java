package main.java.com.playroute.Usuarios.DTO;

import jakarta.validation.constraints.*;
public record LoginRequest(@NotBlank String usuario,@NotBlank String contraseña){

}
