package com.playroute.Usuarios.Config;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;

import com.playroute.Usuarios.Model.Usuario;

@Configuration
public class Seed implements CommandLineRunner{
 @Bean
  CommandLineRunner cargarDatos(
      UsuariosRepository r,
      BCryptPasswordEncoder encoder,
      @Value("${app.admin-password}") String admin,
      @Value("${app.cliente-password}") String cliente) {
    return args -> {
      for (String name : new String[] {"admin", "cliente"}) {
        if (!r.existsByUsuario(name)) {
          Usuario u = new Usuario();
          u.usuario = name;
          u.nombre = name.equals("admin") ? "Administrador GameTech" : "Cliente GameTech";
          u.email = name + "@gametech.local";
          u.rol = name.equals("admin") ? "ADMIN" : "CLIENTE";
          u.passwordHash = encoder.encode(name.equals("admin") ? admin : cliente);
          r.save(u);
        }
      }
    };
  }

}
