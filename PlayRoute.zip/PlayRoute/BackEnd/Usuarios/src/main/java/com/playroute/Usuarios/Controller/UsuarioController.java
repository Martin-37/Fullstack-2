package com.playroute.Usuarios.Controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.playroute.Usuarios.DTO.UsuarioRequestDTO;
import com.playroute.Usuarios.DTO.UsuarioResponseDTO;
import com.playroute.Usuarios.Service.UsuarioService;
import com.playroute.Usuarios.Service.UsuariosService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import main.java.com.playroute.Usuarios.DTO.RegistroRequest;
import main.java.com.playroute.Usuarios.DTO.UsuarioResponse;
import main.java.com.playroute.Usuarios.DTO.UsuarioUpdateRequest;

@RestController
@RequestMapping("/api/usuarios")
@RequiredArgsConstructor
public class UsuarioController {

    private final UsuarioService usuarioService;

  public UsuariosController(UsuariosService service) {
    this.service = service;
  }

    @GetMapping
    public List<UsuarioResponse> listar() {
        return service.listar();
    }

    @GetMapping("/{id}")
    public UsuarioResponse obtener(@PathVariable Long id) {
        return service.obtener(id);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public UsuarioResponse crear(@Valid @RequestBody RegistroRequest request) {
        return service.crear(request);
    }

    @PutMapping("/{id}")
    public UsuarioResponse editar(
            @PathVariable Long id, @Valid @RequestBody UsuarioUpdateRequest request) {
        return service.editar(id, request);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void eliminar(@PathVariable Long id, @AuthenticationPrincipal Jwt jwt) {
        service.eliminar(id, jwt.getSubject());
    }

}
