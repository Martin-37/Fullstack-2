package main.java.com.playroute.Usuarios.DTO;
import jakarta.validation.constraints.*;
public record AuthResultado(Session session, String refresh) {}
