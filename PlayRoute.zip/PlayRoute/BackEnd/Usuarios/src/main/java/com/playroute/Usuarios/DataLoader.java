package com.playroute.Usuarios;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;

import com.playroute.Usuarios.Model.Usuario;
import com.playroute.Usuarios.Repository.UsuarioRepository;

import net.datafaker.Faker;

@Profile ("dev")
public class DataLoader implements CommandLineRunner {

    @Autowired 
    private  UsuarioRepository usuarioRepository;

    @Override
    public void run(String... args) throws Exception {
        // Cargar datos iniciales en la base de datos

        Faker faker = new Faker();
        Random random = new Random();
        
        for (int i = 0; i < 3; i++) {
            Usuario usuario = new Usuario();
            usuario.setNombre(faker.book().genre());
            usuario.setCorreo(faker.book().genre());
            usuario.setContraseña(faker.book().genre());

            
        }
    }

}
